import java.util.Arrays;
import java.util.List;

public class AverageOfListOfIntegers {

	public static void main(String[] args) {
		List<Integer> list = Arrays.asList(23, 56, 78, 12, 46, 89, 11, 134, 234, 1, 5, 9);  
		int average = (int) list.stream().mapToInt((a) -> a).summaryStatistics().getAverage();  
		System.out.println("The average of the List is: "+average);
	}

}
